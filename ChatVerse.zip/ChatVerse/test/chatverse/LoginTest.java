package chatverse;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests for the Login class.
 */
public class LoginTest {

    private Login registeredUser;

    @Before
    public void setUp() {
        // A user with fully valid details, used by the login tests.
        registeredUser = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
    }

    // ---------- Username ----------

    @Test
    public void testUsernameCorrectlyFormatted() {
        assertTrue(registeredUser.checkUserName("kyl_1"));
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        // No underscore and longer than five characters
        assertFalse(registeredUser.checkUserName("kyle!!!!!!!"));
    }

    @Test
    public void testUsernameNoUnderscore() {
        assertFalse(registeredUser.checkUserName("kyle1"));
    }

    @Test
    public void testUsernameTooLong() {
        assertFalse(registeredUser.checkUserName("kyle_123"));
    }

    @Test
    public void testUsernameNull() {
        assertFalse(registeredUser.checkUserName(null));
    }

    // ---------- Password ----------

    @Test
    public void testPasswordMeetsComplexityRequirements() {
        assertTrue(registeredUser.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testPasswordTooShort() {
        assertFalse(registeredUser.checkPasswordComplexity("Ch&99!"));
    }

    @Test
    public void testPasswordNoCapital() {
        assertFalse(registeredUser.checkPasswordComplexity("ch&&sec@ke99!"));
    }

    @Test
    public void testPasswordNoNumber() {
        assertFalse(registeredUser.checkPasswordComplexity("Ch&&sec@ke!!"));
    }

    @Test
    public void testPasswordNoSpecialCharacter() {
        assertFalse(registeredUser.checkPasswordComplexity("Chsecake99"));
    }

    @Test
    public void testPasswordNull() {
        assertFalse(registeredUser.checkPasswordComplexity(null));
    }

    // ---------- Cell phone number ----------

    @Test
    public void testCellPhoneCorrectlyFormatted() {
        assertTrue(registeredUser.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testCellPhoneMissingInternationalCode() {
        assertFalse(registeredUser.checkCellPhoneNumber("0838968976"));
    }

    @Test
    public void testCellPhoneTooManyDigits() {
        assertFalse(registeredUser.checkCellPhoneNumber("+278389689764"));
    }

    @Test
    public void testCellPhoneContainsLetters() {
        assertFalse(registeredUser.checkCellPhoneNumber("+2783896897a"));
    }

    @Test
    public void testCellPhoneNull() {
        assertFalse(registeredUser.checkCellPhoneNumber(null));
    }

    // ---------- Registration ----------

    @Test
    public void testRegisterUserSuccess() {
        String expected = "Username successfully captured.\n"
                + "Password successfully captured.\n"
                + "Cell number successfully captured.";
        assertEquals(expected, registeredUser.registerUser());
    }

    @Test
    public void testRegisterUserBadUsername() {
        Login user = new Login("Kyle", "Smith", "kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("Username is not correctly formatted; please ensure that your username "
                + "contains an underscore and is no more than five characters in length.",
                user.registerUser());
    }

    @Test
    public void testRegisterUserBadPassword() {
        Login user = new Login("Kyle", "Smith", "kyl_1", "password", "+27838968976");
        assertEquals("Password is not correctly formatted; please ensure that the password "
                + "contains at least eight characters, a capital letter, a number, and a "
                + "special character.",
                user.registerUser());
    }

    @Test
    public void testRegisterUserBadCellPhone() {
        Login user = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "0838968976");
        assertEquals("Cell phone number incorrectly formatted or does not contain "
                + "international code.",
                user.registerUser());
    }

    // ---------- Login ----------

    @Test
    public void testLoginSuccessful() {
        assertTrue(registeredUser.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginWrongPassword() {
        assertFalse(registeredUser.loginUser("kyl_1", "wrongPassword1!"));
    }

    @Test
    public void testLoginWrongUsername() {
        assertFalse(registeredUser.loginUser("abc_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginWithUnregisteredUser() {
        Login empty = new Login();
        assertFalse(empty.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    // ---------- Login status messages ----------

    @Test
    public void testReturnLoginStatusSuccess() {
        assertEquals("Welcome Kyle Smith it is great to see you.",
                registeredUser.returnLoginStatus(true));
    }

    @Test
    public void testReturnLoginStatusFailure() {
        assertEquals("Username or password incorrect, please try again.",
                registeredUser.returnLoginStatus(false));
    }

    // ---------- Getters and setters ----------

    @Test
    public void testDefaultConstructorFieldsAreNull() {
        Login empty = new Login();
        assertNull(empty.getFirstName());
        assertNull(empty.getLastName());
        assertNull(empty.getUsername());
        assertNull(empty.getPassword());
        assertNull(empty.getCellPhoneNumber());
    }

    @Test
    public void testSettersAndGetters() {
        Login user = new Login();
        user.setFirstName("Kyle");
        user.setLastName("Smith");
        user.setUsername("kyl_1");
        user.setPassword("Ch&&sec@ke99!");
        user.setCellPhoneNumber("+27838968976");

        assertEquals("Kyle", user.getFirstName());
        assertEquals("Smith", user.getLastName());
        assertEquals("kyl_1", user.getUsername());
        assertEquals("Ch&&sec@ke99!", user.getPassword());
        assertEquals("+27838968976", user.getCellPhoneNumber());
    }
}